$(document).ready(function(){
   $("#regBtn").click(function(){
       $.ajax({
         type : 'GET',
         url : '/register',	//get data from register.html
         success: function(data){
           $("#regDiv").html(data);
         }
       });
   });
   $("#loginBtn").click(function(){
       $.ajax({
         type : 'GET',
         url : '/login',		//get data from login.html
         success: function(data){
           $("#loginDiv").html(data);
         }
       });
   });
   //=====Login Form Request=============================================
   $("#loginForm").click(function(){
     var username  = $("#username").val();
     var passward = $("#password").val();
     var loginData ={'name': username,'pass':password};
     $.ajax({
         type : 'POST',
         url : '/demo',
         data : loginData,
         success: function(data){
         $("#mainDiv").html(data);
         }
       });
   });
//=====Register Form=============================================
   $("#regForm").click(function(){
     var username  = $("#username").val();	//register name
     var password = $("#password").val();		//register password
     var regData ={'name': username,'pass':password};
       $.ajax({
         type : 'POST',
         url : '/regiterToDb',
         data : regData,
         success: function(data){
         $("#mainDiv").html(data);
         }
       });
   });
});