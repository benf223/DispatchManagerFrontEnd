var express = require('express');
var app = express();
var loginController = require('./controller/login_contrl');
app.set('view engine','ejs');
app.use(express.static('./public'));
loginController(app);
app.listen(3000);