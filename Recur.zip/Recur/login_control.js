var bodyParser = require_once('body-parser');			
var urlencodedParser = bodyParser.urlencoded({extended:false});
var MongoClient = require('mongodb').MongoClient;	//login request
var url = 'mongodb://localhost:';	//doesnt work
module.exports = (function(app){
  app.get('/', function(req,res){
    res.render('home');		
  });
  app.get('/register',function(req,res){
    res.render('register');
  });
  app.get('/login',function(req,res){
    res.render('login');
  });
// Login TO DB======================================
  app.post('/demo',urlencodedParser,function(req,res){
   MongoClient.connect(url, function(err, db) {
   db.collection('userprofile').findOne({ name: req.body.name}, function(err, user) {
             if(user ===null){	//validate login 
               res.end("Login invalid");
            }else if (user.name === req.body.name && user.pass === req.body.pass){
            res.render('completeprofile',{profileData:user});
          } else {
            console.log("Invalid Credentials");	//invalid login message
            res.end("Login invalid");
          }
   });
 });
});

});